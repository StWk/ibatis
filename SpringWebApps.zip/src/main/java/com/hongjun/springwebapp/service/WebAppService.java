package com.hongjun.springwebapp.service;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.hongjun.springwebapp.model.UserCreateReqDto;
import com.hongjun.springwebapp.model.UserCreateResDto;
import com.hongjun.springwebapp.model.UserDeleteResDto;
import com.hongjun.springwebapp.model.UserModifyReqDto;
import com.hongjun.springwebapp.model.UserModifyResDto;
import com.hongjun.springwebapp.model.UserReadListResDto;
import com.hongjun.springwebapp.model.UserReadResDto;

@Service
public class WebAppService {
	private static final Logger logger = LoggerFactory.getLogger(WebAppService.class);
	
	public UserCreateResDto userCreate(UserCreateReqDto reqDto, Model model) {
		logger.debug("userCreate");
		
		UserCreateResDto resDto = new UserCreateResDto();
		return resDto;
	}
	public UserReadResDto userRead(String userId, Model model) {
		logger.debug("userRead");

		UserReadResDto resDto = new UserReadResDto();
		return resDto;
	}
	public ArrayList<UserReadListResDto> userList(Model model) {
		logger.debug("userList");
		
		ArrayList<UserReadListResDto> list = new ArrayList<UserReadListResDto>();
		
		UserReadListResDto resDto = new UserReadListResDto();
		list.add(resDto);
		
		return list;
	}
	public UserModifyResDto userModify(UserModifyReqDto reqDto, String userId, Model model) {
		logger.debug("userModify");
		
		UserModifyResDto resDto = new UserModifyResDto();
		return resDto;
	}
	public UserDeleteResDto userDelete(String userId, Model model) {
		logger.debug("userDelete");
		
		UserDeleteResDto resDto = new UserDeleteResDto();
		return resDto;
	}
}
